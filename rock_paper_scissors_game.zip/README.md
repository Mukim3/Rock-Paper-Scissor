# 🎮 Rock Paper Scissors Game (Python GUI)

A fun and interactive Rock-Paper-Scissors game built using Python and Tkinter.

## ✅ Features

- Choose between Rock, Paper, or Scissors
- Random computer choice
- Score tracking
- Reset game option
- User-friendly GUI

## 🖥️ Technologies Used

- Python 3.x
- Tkinter (built-in GUI library)
- Random module

## ▶️ How to Run

1. Download the repository or ZIP
2. Run this command:
   ```bash
   python rock_paper_scissors.py
   ```

## 📦 Requirements

- No external packages needed (uses only built-in libraries)

## 💡 Future Enhancements

- Sound effects
- Timer-based rounds
- Animated choices

---

Made with 💙 using Python and Tkinter
